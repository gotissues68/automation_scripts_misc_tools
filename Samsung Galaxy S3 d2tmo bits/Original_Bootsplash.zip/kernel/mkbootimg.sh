#!/sbin/sh
cd /tmp/
/tmp/dd if=/dev/block/mmcblk0p7 of=/tmp/boot.img
/tmp/unpackbootimg /tmp/boot.img
mkdir /tmp/ramdisk
cd /tmp/ramdisk
gunzip -c ../boot.img-ramdisk.gz | cpio -i
cp /tmp/initlogo.rle /tmp/ramdisk/
find . | cpio -o -H newc | gzip > ../ramdisk.img
cd ..
/tmp/mkbootimg --kernel /tmp/boot.img-zImage --ramdisk /tmp/ramdisk.img --cmdline 'androidboot.hardware=qcom user_debug=31' --base 0x80200000  --ramdiskaddr 0x81500000 -o /tmp/newboot.img
/tmp/dd if=/tmp/newboot.img of=/dev/block/mmcblk0p7
